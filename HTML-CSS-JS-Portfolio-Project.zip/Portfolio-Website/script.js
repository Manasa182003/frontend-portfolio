function showMessage() {
    document.getElementById("msg").innerText =
        "Thank you for visiting my portfolio!";
}
